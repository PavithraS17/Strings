import java.util.*;
public class Sprgm10 {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the String");
		String str1=s.next();
		System.out.println("Enter n values");
		int n=s.nextInt();
		int n1=str1.length();
		String str2=str1.substring(n1-n);
		for(int i=0;i<n;i++)
		{
			System.out.print(str2);
		}
		
}
}
