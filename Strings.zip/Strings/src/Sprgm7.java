import java.util.Scanner;
public class Sprgm7 {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the String");
		String str1=s.next();
		int n=str1.length();
		if((str1.startsWith("x"))&& (str1.endsWith("x")))
		{
			System.out.println(str1.substring(1,n-1));
		}
		else {
			System.out.println(str1);
		}
	}
}
