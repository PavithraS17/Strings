import java.util.Scanner;

import java.util.Scanner;
public class Sprgm2 {
	public static void main(String[] args) {
		
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the String s1");
		String str1=s.next().toLowerCase();
		System.out.println("Enter the String s2");
		String str2=s.next().toLowerCase();
		int n1=str1.length();
		int n2=str2.length();
		char a1=str1.charAt(n1-1);
		char a2=str2.charAt(0);
		String b1=Character.toString(a1);
		String b2=Character.toString(a2);
		if(b1.equals(b2)) {
			  String str3=str2.substring(1,n2).toLowerCase();
			System.out.println(str1+str3);
		}
		else {
			System.out.println(str1+" "+str2);
		}
		

	}
}
