import java.util.Scanner;
public class Sprgm1 {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the string");
		String s1=s.next();
		StringBuffer sb=new StringBuffer(s1);
		String s2=sb.reverse().toString();
		if(s1.equals(s2))
		{
			System.out.println("The String is a Palindrome");
		}
		else {
			System.out.println(" The String is Not a Palindrome");
		}
	}


}
