import java.util.Scanner;
public class Sprgm3 {
	public static void main(String[] args) {
		
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the String");
		String str1=s.next();
		String str2=str1.substring(0, 2);
		int n=str1.length();
		for(int i=0;i<n;i++) {
		System.out.print(str2);
		}
	}
}
