import java.util.*;
public class Sprgm8 {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the String");
		String str=s.next();
		StringBuilder sb=new StringBuilder();
		sb.append(str);
		String[] s2=str.split("");
		for(int i=0;i<s2.length;i++)
		{
			if(s2[i].equals("*"))
			{
				str=sb.delete(i-1, i+2).toString();
				break;
			}
		}
		System.out.println(str);
		
	}
}
