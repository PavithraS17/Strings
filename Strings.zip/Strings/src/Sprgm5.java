import java .util.Scanner;
public class Sprgm5 {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the String");
		String str=s.next();
		int n=str.length();
		System.out.println(str.substring(1, n-1));
		}
}
